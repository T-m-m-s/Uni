<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="authenticity_token" name="csrf-param" />
    <title>Tracking Page</title>
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="css/all.css">
    <link rel="stylesheet" type="text/css" href="css/boostrap.min.css">
    <script src="javascript/jquery-3.1.0.min.js"></script>

    <script type="text/javascript">
      var geocoder;
      var map;
      var bounds;
      var markers=[];

      var rgbToHex = function (rgb) { 
        var hex = Number(rgb).toString(16);
        if (hex.length < 2) {
          hex = "0" + hex;
        }
        return hex;
      };

      $(document).ready(function() {
        setInterval(updatingData, 1000);
      });

      function init() {
        geocoder = new google.maps.Geocoder();
        var latlng = new google.maps.LatLng(46.064656,13.21106);
        bounds  = new google.maps.LatLngBounds();
        var opt = {
          zoom: 10,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          center: latlng,
        }
        map = new google.maps.Map(document.getElementById("map"), opt);
      }

      //funzione di aggiornamento dati
      function updatingData() {
        console.log("server.php");

        $.ajax({
          //parametri per la comunicazione con il server
          url: "server.php",
          type:"GET",
          dataType: "json",
          crossDomain: true,
          ContentType: "application/json",
    
          //funzione di successo di connessione
          success: function(data, textStatus, jqXHR){
            bounds  = new google.maps.LatLngBounds();
            //decodifico i dati ed aggiorno le posizioni dei marker
            var json = JSON.parse(JSON.stringify(data));
            console.log(json);

            list=document.getElementById("entities_list");
            list.innerHTML="<h3>List:</h3><ul>";

            for(i=0; i<json.length; i++) {
              var markerFound=false;
	            var myLatLng = {'lat': parseFloat((json[i]).lat), 'lng': parseFloat((json[i]).lon)};
              var label=(json[i]).entity_name+'\nLat: '+(json[i]).lat+'\nLon: '+(json[i]).lon;

              for(j=0; j<markers.length; j++) {
                if((markers[j]).title.startsWith((json[i]).entity_name)) {
                  markerFound=true;
                  break;
                }
              }

              console.log("Marker already found: "+markerFound);
              if(markerFound) {
                console.log(myLatLng);
                (markers[j]).setPosition(myLatLng);
                (markers[j]).title=label;
                markerColor=(markers[j]).icon.fillColor;
                console.log("label: "+(markers[i]).title);
              }
              else {
                markerColor="#"+rgbToHex(Math.floor(Math.random()*256)).toString()+rgbToHex(Math.floor(Math.random()*256)).toString()+rgbToHex(Math.floor(Math.random()*256)).toString();
                console.log("color:"+markerColor);
                markers.push(new google.maps.Marker({
                  position: myLatLng,
                  map: map,
                  title: label,
                  icon:{
                    path: 'm 12,2.4000002 c -2.7802903,0 -5.9650002,1.5099999 -5.9650002,5.8299998 0,1.74375 1.1549213,3.264465 2.3551945,4.025812 1.2002732,0.761348 2.4458987,0.763328 2.6273057,2.474813 L 12,24 12.9825,14.68 c 0.179732,-1.704939 1.425357,-1.665423 2.626049,-2.424188 C 16.809241,11.497047 17.965,9.94 17.965,8.23 17.965,3.9100001 14.78029,2.4000002 12,2.4000002 Z',
                    fillColor: markerColor,
                    fillOpacity: 1.0,
                    strokeColor: '#000000',
                    strokeWeight: 1,
                    scale: 2,
                    anchor: new google.maps.Point(12, 24),
                  },
                }));
                console.log("label: "+(markers[i]).title);
              }
              map.setCenter(myLatLng);
              list.innerHTML+="<li><span style=\"background-color: "+markerColor+"\">Label: <strong>"+(json[i]).entity_name+"</strong></span><br/>Lat: "+(json[i]).lat+"<br/>Lon: "+(json[i]).lon+"<br/></li>";
              loc = new google.maps.LatLng((json[i]).lat, (json[i]).lon);
              //bounds.extend(loc);
            }

            list.innerHTML+="</ul>";
            //map.fitBounds(bounds);       // auto-zoom
            //map.panToBounds(bounds);     // auto-center

            console.log("connection success : " + textStatus);
          },
    
          //funzione di errore di connessione
          error :function(jqXHR, textStatus, errorThrown){
            console.error("error : " + jqXHR + " : " + textStatus + " : " + errorThrown);
          },
    
          //funzione di completamento di connessione
          complete :function(qXHR, textStatus){
            //console.log("complete : " + textStatus);
          }
        })
      }
    </script>
    <!--Carica le Api necessarie per inizializzare la mappa-->
    <script src="https://maps.googleapis.com/maps/api/js?key=<inserire qui la propria chiave>"></script>
  </head>
  <body onload="javascript:init()">
    <table style="width:100%; height:100%">
      <tr>
        <td valign="top" style="width:20%; height:100%; padding-left:10px">
          <div id="entities_list"></div>
        </td>
        <td style="width:90%; height:100%"><div id="map" style="width:100%; height:100%"></div></td>
      </tr>
    </table>
  </body>
</html>

