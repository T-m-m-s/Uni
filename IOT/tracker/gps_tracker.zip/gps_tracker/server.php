<?php
  header('Cache-Control: no-cache, must-revalidate');
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Credentials: false');
  header('Content-type: application/json; charset=utf-8');

  //Converte le coordinate dal formato NMEA a decimali per l'uso in Google Maps
  function gpsConversion($coord, $hemisphere) {
    $d = floor($coord/100);
    $m = $coord-$d*100;
    if($hemisphere == 'N' || $hemisphere == 'E'){
      return sprintf("%.6f", $d+$m/60);
    }else{
      return sprintf("%.6f",-($d+$m/60));
    }
  }
  
  $host = "127.0.0.1";
  $port = 4545;
  
  $socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");
  $result = socket_connect($socket, $host, $port) or die("Could not connect to server\n");  
  $result = socket_read($socket, 4096) or die("Could not read server response\n");

  $json_obj=json_decode($result);
  $json_obj->lat=gpsConversion($json_obj->lat,$json_obj->latdir);
  $json_obj->lon=gpsConversion($json_obj->lon,$json_obj->londir);
  
  echo '['.json_encode($json_obj).']';
  socket_close($socket);
?>